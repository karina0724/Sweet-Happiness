<style>
        .footer{
            margin-top:20px;
            background: #284243;
            width: 100%;
            height:auto;
            padding: 30px 0;
            color:#fff;
            
        }
        .img-1 img{
            width: 100px;
            height: 100px;
            vertical-align: top;
            margin: 20px;
        }
    </style>
<div class="footer text-center">
               <div class="img-1 f">
                   <img src="img/escudo.png" alt="Escudo Dominicano">
                   <img src="img/logo.png" alt="Sweet Happiness">
               </div>
               <div class="f">
                   <a href="#">Cadena de Hoteles Sweet Happiness</a>
                   <!--[ESPECIFICAR LA RUTA AL INICIO DEL PORTAL]-->
                   <p>Calle 89 #45 Mirador Sur, RD.</p>
                   <p>809-545-5454</p>
                   <p>TÉRMINOS DE USO | POLÍTICAS DE PRIVACIDAD | PREGUNTAS FRECUENTES</p>
                   <span>&copy; 2021 - Todos los Derechos Reservados</span>
               </div><br>
               <div class="f">
                   <img src="images/nortic.jpg" height="100" alt="NORTIC A2" />
                   <!--[RESERVADO PARA SELLO DE CERTIFICACION DE LA NORTIC A2]-->
               </div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

</body>

</html>