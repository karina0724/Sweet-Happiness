

            <div class="servicios">
              <div>
                <h2>Nuestros Servicios</h2>
              </div>
              <div class="row">
                <!-- Gallery item -->
                <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                  <div class="bg-white rounded shadow-sm"><img src="img/servicioPlaya.jpg" alt="Playa"
                      class="img-fluid card-img-top">
                    <div class="p-4">
                      <h5> <a href="#" class="text-dark">Playa</a></h5>
                    </div>
                  </div>
                </div>
                <!-- End -->
<!-- Gallery item -->
            <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                  <div class="bg-white rounded shadow-sm"><img src="img/servicioBar.jpg" alt=""
                      class="img-fluid card-img-top">
                    <div class="p-4">
                      <h5> <a href="#" class="text-dark">Bar</a></h5>
                    </div>
                  </div>
                </div>
                <!-- End -->
                <!-- Gallery item -->
                <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                  <div class="bg-white rounded shadow-sm"><img src="img/servicioRestaurant.jpg" alt=""
                      class="img-fluid card-img-top">
                    <div class="p-4">
                      <h5> <a href="#" class="text-dark">Restaurant</a></h5>
                    </div>
                  </div>
                </div>
                <!-- End -->
                <!-- Gallery item -->
                <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                  <div class="bg-white rounded shadow-sm"><img src="img/servicioBanquete.jpg" alt=""
                      class="img-fluid card-img-top">
                    <div class="p-4">
                      <h5> <a href="#" class="text-dark">Banquete</a></h5>
                    </div>
                  </div>
                </div>
                <!-- End -->
                <!-- Gallery item -->
                <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                  <div class="bg-white rounded shadow-sm"><img src="img/servicioHabitacion.jpg" alt=""
                      class="img-fluid card-img-top">
                    <div class="p-4">
                      <h5> <a href="#" class="text-dark">Habitación</a></h5>
                    </div>
                  </div>
                </div>
                <!-- End -->
                <!-- Gallery item -->
                <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                  <div class="bg-white rounded shadow-sm"><img src="img/servicioPiscina.jpg" alt=""
                      class="img-fluid card-img-top">
                    <div class="p-4">
                      <h5> <a href="#" class="text-dark">Piscina</a></h5>
                    </div>
                  </div>
                </div>
              </div>
              <!-- End -->