<?php

    define('DB_HOST','localhost');
    define('DB_USER','id16646915_root');
    define('DB_PASS','~l]g0eul&X6sRvlv');
    define('DB_NAME','id16646915_final_administracion');

     