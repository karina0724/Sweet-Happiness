	<div class="social">
		<a href="#"><i class="fab fa-facebook fa-2x" style="color: #006CF5;"></i></a>
		<a href="#"><i
        class="fab fa-twitter fa-2x mt-2" style="color:#4B9AFF;"></i></a>
		<a href="#"><i class="fab fa-instagram fa-2x mt-2" style="color:#C33333;"></i></a>
	</div>

<style>

.container{
  width:95%;
  max-width:900px;
  margin:auto;
}

.social{
  /*las imágenes usadas tienen width de 48px*/
  width:48px;
  position:fixed;
  top:50px;
  right:0;
}

/* Extra centrado vertical*/

.social{
  /*border:1px solid #000;*/
  top:50%;
  height:205px;
  /*para poner height 192 deberíamos haber indicado en el reset de estilos font-size:0;*/
  margin-top:-100px;
}

</style>